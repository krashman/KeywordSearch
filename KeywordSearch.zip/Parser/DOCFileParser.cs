﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Code7248.word_reader;

namespace $safeprojectname$
{
    class DOCFileParser : Parsers
    {
        //string filePath;

        public string gettext(string filePath)
        {
            try
            {
                string fileData = "";

                Code7248.word_reader.TextExtractor extractor = new TextExtractor(filePath);

                fileData = extractor.ExtractText();

                return fileData;
            }
            catch (Exception e)
            {
                $safeprojectname$.Utilities.WriteLOG.Instance.writeLOG("Error in Doc/Docx parsing  " + filePath + "     " + Environment.NewLine + e);
                return "";
            }
        }
    }
}
