﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class XMLFileParser : Parsers
    {
       // string filePath;

        public string gettext(string filePath){
            string fileData = "";


            return fileData;
        }
    }
}
