﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class TEXTFileParser : Parsers
    {
        private string fileData = "";
        public string gettext(string filePath)
        {
            try
            {
                // Create an instance of StreamReader to read from a file. 
                // The using statement also closes the StreamReader. 
                using (StreamReader sr = new StreamReader(filePath))
                {
                    string line;

                    // Read and display lines from the file until the end of  
                    // the file is reached. 
                    while ((line = sr.ReadLine()) != null)
                    {
                        this.fileData += line;
                    }
                }
                return this.fileData;
            }
            catch (Exception e)
            {
                $safeprojectname$.Utilities.WriteLOG.Instance.writeLOG("Error in txt/htm/html/xml parsing  " + filePath + "     " + Environment.NewLine + e);
                return "";
            }

        }
    }
}
