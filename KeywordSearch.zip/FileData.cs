﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    class FileData
    {
        private string filePath;
        private Parsers fileParser;
        private string resultData;
        public FileData(string path) {
            this.filePath = path;
        }

        public string getData() {
            try
            {
                string[] separators = { "." };
                string[] words = this.filePath.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                string fileType = words[words.Length - 1];

                if (fileType == "doc")
                {
                    fileParser = new DOCFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    // MessageBox.Show(resultData);
                }
                else if (fileType == "docx")
                {
                    fileParser = new DOCFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    // MessageBox.Show(resultData);
                }
                else if (fileType == "ppt")
                {
                    fileParser = new PPTFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    //MessageBox.Show(resultData);
                }
                else if (fileType == "pptx")
                {
                    fileParser = new PPTFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    // MessageBox.Show(resultData);
                }
                else if (fileType == "xls")
                {
                    fileParser = new XLSFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    // MessageBox.Show(resultData);
                }
                else if (fileType == "xlsx")
                {
                    fileParser = new XLSFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    // MessageBox.Show(resultData);
                }
                else if (fileType == "pdf")
                {
                    fileParser = new PDFFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    // MessageBox.Show(resultData);
                }
                else if (fileType == "xml")
                {
                    fileParser = new TEXTFileParser(); //new XMLFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    //MessageBox.Show(resultData);
                }
                else if (fileType == "htm")
                {
                    fileParser = new TEXTFileParser(); //new HTMFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    //MessageBox.Show(resultData);
                }
                else if (fileType == "html")
                {
                    fileParser = new TEXTFileParser(); //new HTMLFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    //MessageBox.Show(resultData);
                }
                else if (fileType == "txt")
                {
                    fileParser = new TEXTFileParser();
                    resultData = fileParser.gettext(this.filePath);
                    //MessageBox.Show(resultData);
                }
                else
                {
                    resultData = "";
                }

                return resultData;
            }
            catch(Exception e) {
                $safeprojectname$.Utilities.WriteLOG.Instance.writeLOG(""+e+ Environment.NewLine);
                return "";
            }
        }
    }
}
