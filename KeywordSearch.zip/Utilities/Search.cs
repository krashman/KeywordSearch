﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    class Search
    {
        private String keyWords;
        private String delimitor;
        public Search(string keywordsString, string seperator) {
            this.keyWords = keywordsString;
            this.delimitor = seperator;
        }

        public string getSearchResults(string sourceString) {
            try
            {
                string searchResults = "";
                string[] seperator = { "," };
                int counter = 0;
                int occurrence = 0;
                //delimitor.ToCharArray;
                //seperator.SetValue(delimitor,0);
                string[] keyword = this.keyWords.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < keyword.Length; i++)
                {
                    occurrence = countKeywordOccurrence(sourceString, keyword[i].Trim());
                    searchResults += keyword[i].Trim() + this.delimitor + occurrence + this.delimitor;
                    if (occurrence > 0)
                    {
                        counter++;
                    }
                }
                return searchResults + counter;
            }
            catch (Exception e)
            {
                $safeprojectname$.Utilities.WriteLOG.Instance.writeLOG("Error with searchkeyword module   " + Environment.NewLine + e);
                return "";
            } 
        }

        private int countKeywordOccurrence(string source, string keyword) {
            int count = 0, n = 0;
            if (keyword != ""){
                while ((n = source.IndexOf(keyword, n, StringComparison.OrdinalIgnoreCase)) != -1){
                    n += keyword.Length;
                    ++count;
                }
            }
            return count;
        }
    }
}
