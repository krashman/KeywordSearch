﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    class WriteResult
    {
        private string destinationPath;
        private string destinationLOGPath;
        private int indexCounter = 1;
        public WriteResult(string path) {
            this.destinationPath = path;
            $safeprojectname$.Utilities.WriteLOG log = $safeprojectname$.Utilities.WriteLOG.Instance;
            log.setPath(path);
            log.createLOGFile();
        }

        public Boolean createFiles() {
            try
            {
                //  ID+Name+Path+DateCreated+DateLastModified+DateLastAccessed+Size+Owner+Attributes+FileExtension+RootFolder+DayCreated+MonthCreated+
                //  YearCreated+DayLastModified+MonthLastModified+YearLastModified+DayLastAccessed+MonthLastAccessed+YearLastAccessed+ReadOnlyFlag+HiddenFlag+SystemFlag
                //  ReadOnly+Hidden+SystemFile+Size in KB
                string text = "S.No|Name|Path|DateCreated|DateLastModified|DateLastAccessed|Size|Owner|Attributes|";
                // WriteAllText creates a file, writes the specified string to the file, 
                // and then closes the file.  
                System.IO.File.WriteAllText(@destinationPath, text + Environment.NewLine);
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show("Please enter valid path to save results.  " + e);
                return false;
            }
        
        }

        public Boolean writeString(string data) {
            try
            {
                string destinationPath = this.destinationPath;
                // The using statement automatically closes the stream and calls  
                // IDisposable.Dispose on the stream object. 
                int len = data.Length;
                //MessageBox.Show(len + "   " + data.ElementAt(len - 1));
                int val = (int)Char.GetNumericValue(data.ElementAt(len - 1));
                data = data.Substring(0, len - 1);
                if (val > 0)
                {
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(@destinationPath, true))
                    {
                        file.WriteLine( this.indexCounter +  data + Environment.NewLine);
                        indexCounter++;
                    }
                }
                return true;
            }
            catch(Exception e) {
               // MessageBox.Show("Error in file writing  "+e);
                $safeprojectname$.Utilities.WriteLOG.Instance.writeLOG("Error in file writing  " + e);
                return false;
            }
        }

    }
}
