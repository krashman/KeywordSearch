﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.Utilities
{
    class WriteLOG
    {

        private static WriteLOG instance = null;
        private string destinationLOGPath;
        private WriteLOG()
        {
        }

        public static WriteLOG Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new WriteLOG();
                }
                return instance;
            }
        }

        public void setPath(string path) {
            this.destinationLOGPath = path.Substring(0, path.LastIndexOf(".") - 1) + "LOG.txt";
        }

        public void createLOGFile()
        {
            try
            {
                string logPath = this.destinationLOGPath;
                System.IO.File.WriteAllText(logPath, "Execution Error Log: ");
            }
            catch (Exception e)
            {
                MessageBox.Show("Please enter valid Log path to save results.  " + e);
            }
        }

        public Boolean writeLOG(string log)
        {
            try
            {
                string dLOGPath = this.destinationLOGPath;

                using (System.IO.StreamWriter file = new System.IO.StreamWriter(@dLOGPath, true))
                {
                    file.WriteLine(log + Environment.NewLine);
                }
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show("Please enter valid Log path to save results.  " + e);
                return false;
            }

        }

    }
}
