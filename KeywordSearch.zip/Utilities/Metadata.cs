﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Metadata
    {
        private string filePath;
        private string delimitor;
        public Metadata(string path, string seperator)
        {
            this.filePath = path;
            this.delimitor = seperator;
        }

        public string getMetadata()
        {
            try
            {
                string metaData = "";

                FileInfo oFileInfo = new FileInfo(this.filePath);
                string user = System.IO.File.GetAccessControl(filePath).GetOwner(typeof(System.Security.Principal.NTAccount)).ToString();


                DateTime dtCreationTime = oFileInfo.CreationTime;
                metaData = oFileInfo.Name + this.delimitor + oFileInfo.DirectoryName + this.delimitor +
                    oFileInfo.CreationTime + this.delimitor + oFileInfo.LastWriteTime + this.delimitor + oFileInfo.LastAccessTime + this.delimitor +
                    oFileInfo.Length.ToString() + this.delimitor + user + this.delimitor + oFileInfo.Attributes + this.delimitor +
                    oFileInfo.Extension + this.delimitor + oFileInfo.Directory + this.delimitor + getDateString(oFileInfo.CreationTime) + this.delimitor +
                    getDateString(oFileInfo.LastWriteTime) + this.delimitor + getDateString(oFileInfo.LastAccessTime) + this.delimitor +
                    getfileAttributes(filePath);

                return metaData;
            }
            catch (Exception e)
            {
                $safeprojectname$.Utilities.WriteLOG.Instance.writeLOG("Error in metadata extraction module.   " + Environment.NewLine + e);
                return "";
            }
        }

        private string getDateString(DateTime fileDate)
        {
            DateTime datevalue = (Convert.ToDateTime(fileDate.ToString()));

            String dy = datevalue.Day.ToString();
            String mn = datevalue.Month.ToString();
            String yy = datevalue.Year.ToString();

            return dy + this.delimitor + mn + this.delimitor + yy;
        }

        private string getfileAttributes(string filePath)
        {
            try
            {
                string attributeString;
                int isReadOnly = 0;
                int isHidden = 0;
                int isSystem = 0;
                if ((File.GetAttributes(filePath) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                {
                    isReadOnly = 1;
                }

                // check whether a file is hidden
                if ((File.GetAttributes(filePath) & FileAttributes.Hidden) == FileAttributes.Hidden)
                {
                    isHidden = 1;
                }

                // check whether a file is system file
                if ((File.GetAttributes(filePath) & FileAttributes.System) == FileAttributes.System)
                {
                    isSystem = 1;
                }

                attributeString = isReadOnly + this.delimitor + isHidden + this.delimitor + isSystem;
                return attributeString;
            }
            catch (Exception e)
            {
                $safeprojectname$.Utilities.WriteLOG.Instance.writeLOG("Error Metadata - fileAttribute extraction  " + Environment.NewLine + e);
                return "";
            }
        }
    }
}
