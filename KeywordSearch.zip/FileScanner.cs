﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
//using System.IO.File.GetAccessControl;

namespace $safeprojectname$
{
    public partial class FileScanner : Form
    {
        public FileScanner(){
            InitializeComponent();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e){

        }

        private void Form1_Load(object sender, EventArgs e){

        }

        private void label2_Click(object sender, EventArgs e){

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e){

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e){
            Application.Exit();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e){

        }

        private void button2_Click(object sender, EventArgs e){   
            //MessageBox.Show("button2_Click");

            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK){
                this.textBox1.Text = folderBrowserDialog1.SelectedPath;
            }

        }

        private void button3_Click(object sender, EventArgs e){
           // MessageBox.Show("button3_Click");
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK){
                this.textBox2.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void button1_Click(object sender, EventArgs e){
           // MessageBox.Show("button1_Click");
            string[] filePaths;
            string filePath;
            WriteResult writeFile;
            string delimitor = this.textBox3.Text;
            string keywords = this.textBox4.Text;
            string sourceString = "";
            string resultString;
            try
            {
                if (keywords != null)
                {
                    if (checkBox1.Checked == true)
                    {
                        filePaths = Directory.GetFiles(this.textBox1.Text, "*", SearchOption.AllDirectories);
                        //   MessageBox.Show("Checked");
                    }
                    else
                    {
                        filePaths = Directory.GetFiles(this.textBox1.Text);
                        //   MessageBox.Show("UnChecked");
                    }

                    writeFile = new WriteResult(this.textBox2.Text);
                    writeFile.createFiles();
                    for (int index = 0; index < filePaths.Length; index++)
                    {

                        filePath = filePaths[index];
                        string metaData = new Metadata(filePath, delimitor).getMetadata();
                        sourceString = new FileData(filePath).getData();

                        if (sourceString != null || sourceString == "")
                        {
                            string keywordOccurrenceData = new Search(keywords, delimitor).getSearchResults(sourceString);
                            resultString = delimitor + metaData + delimitor + keywordOccurrenceData;
                            writeFile.writeString(resultString);
                        }
                    }
                    MessageBox.Show("Done..!!");
                }
            }catch(Exception exp){
                MessageBox.Show("Error in Main.  " + exp);
            }
        }

        private void folderBrowserDialog1_HelpRequest_1(object sender, EventArgs e){

        }
       
    }
}
